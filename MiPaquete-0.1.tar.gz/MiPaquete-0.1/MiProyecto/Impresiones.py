class Impresiones:
    def imprimir(self):
        return 'se va a imprimir esto'