from setuptools import setup

setup(name='MiPaquete',
      version='0.1',
      description='Este es mi paquete',
      url='https://github.com/aterron71/MiProyecto',
      author='Angel Terron',
      author_email='angel.terron@softver.com.mx',
      license='MIT',
      packages=['MiProyecto'],
      zip_safe=False)